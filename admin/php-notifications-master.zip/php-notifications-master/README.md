
For detailed explaination head over to : https://www.cloudways.com/blog/real-time-php-notification-system/ 



